suppressPackageStartupMessages(library(testthat))
suppressPackageStartupMessages(library(SpiecEasi))

testthat::test_check("SpiecEasi")
